function konvertujMinute(n){
    return Math.floor(n/60)+" Sati i "+n%60+" minuta";
}


console.log(konvertujMinute(213));
