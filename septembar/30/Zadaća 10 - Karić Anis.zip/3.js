function $toKM(n){
    return n*1.71;
}

console.log($toKM(100));