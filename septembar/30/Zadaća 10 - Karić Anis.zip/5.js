function max(a,b){
    if(a>b)return a;
    else if(b>a) return b;
}

console.log(max(4,-5));
