function DOB(starost){
    return 2024-starost;
}


console.log(DOB(21));
