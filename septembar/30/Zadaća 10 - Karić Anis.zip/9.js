function brojiCifre(n){
    return (""+n).length;
}

console.log(brojiCifre(12345));
