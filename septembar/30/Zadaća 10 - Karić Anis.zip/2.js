function ZRPK(a,b){
    let zbir=a+b,razlika=a-b,proizvod=a*b,kolicnik=a/b;

    return "Zbir:"+zbir+" \nRazlika:"+razlika+"\nProizvod:"+proizvod+"\nKolicnik:"+kolicnik;
}

console.log(ZRPK(3,3));