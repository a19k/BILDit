function stepen(baza,eksponent){
    return baza**eksponent;
}


console.log(stepen(5,2))