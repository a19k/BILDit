function parnost(a){
    if(a%2==0)return true;
    else return false;
}

console.log(parnost(5));