function ispisN(poruka,broj){
    for(let i=0;i<broj;i++) console.log(poruka);
}


ispisN("bass",4);