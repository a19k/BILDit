function DjeljivoSa100(){
    br=0;
    i=0;
    while(br<100){
        if(i%5==0 && i%6==0) {br++;console.log(i)};
        i++;
    }
}

DjeljivoSa100();