//Kvadrat brojeva u opsegu

let n = 6;

for (let i = 1; i <= n; i++) console.log(i ** 2);