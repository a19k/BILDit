//Suma kvadrata u opsegu

let n=4;

let sum=0;

for(let i=1;i<=n;i++)sum+=i**2;

console.log(sum);
