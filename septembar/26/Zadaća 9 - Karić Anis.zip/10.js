//Tablica množenja

let n = 5;

for (let i = 1; i <= 10; i++) console.log(n * i);