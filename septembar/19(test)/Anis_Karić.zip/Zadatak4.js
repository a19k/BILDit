for (let i = 2; i < 30; i++) {
    if (i % 2 == 0 && i % 3 == 0) console.log("djeljiv sa 2 i 3");
    else if (i % 2 == 0) console.log("djeljiv sa 2");
    else if (i % 3 == 0) console.log("djeljiv sa 3");
    else console.log(i);
}