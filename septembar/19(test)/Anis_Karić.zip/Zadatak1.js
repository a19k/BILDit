var sum = 0;
var i = 10;

do {
    sum += i++;
}
while (i < 20)

console.log(sum);