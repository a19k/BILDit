//https://edabit.com/challenge/QkuiL7XApt2RMQqTJ

const REGEXP = /[0-9][0-9]:[0-9][0-9]/