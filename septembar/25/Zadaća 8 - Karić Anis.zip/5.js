//https://edabit.com/challenge/7KbZc8QvzqrJPaE6Q

const REGEXP = /red flag|blue flag/g