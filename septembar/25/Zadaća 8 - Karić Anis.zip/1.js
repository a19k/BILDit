function hello() {
	return "hello edabit.com"
}