//https://edabit.com/challenge/vvuAkYEAArrZvmp6X

function bitwiseAND(n1, n2) {
	return n1&n2;
}

function bitwiseOR(n1, n2) {
	return n1|n2;
}

function bitwiseXOR(n1, n2) {
	return n1^n2;
}