//https://edabit.com/challenge/pB6CF3rFBi8ykJ3Br

function shiftToLeft(x, y) {
	return x*2**y;
}